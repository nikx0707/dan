package com.example.customlistview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class CustomAdapter extends BaseAdapter {

    String fruitList[];
    int imageList[];
    Context context;
    LayoutInflater layoutInflater;

    public CustomAdapter(String[] fruitList, int[] imageList, Context context) {
        this.fruitList = fruitList;
        this.imageList = imageList;
        this.context = context;

        layoutInflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return fruitList.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        view = layoutInflater.inflate(R.layout.activity_custom_list_view,null);

        TextView txt = view.findViewById(R.id.textView);
        ImageView img = view.findViewById(R.id.imageIcon);

        txt.setText(fruitList[i]);
        img.setImageResource(imageList[i]);

        return view;
    }
}
