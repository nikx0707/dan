package com.example.customlistview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    String fruitList [] = {"Apple","Banana","Carrot","Cauliflower","Mango","Onion","Orange","Potato","Pumkin","Tomato"};
    int imageList [] = {R.drawable.apple,R.drawable.banana,R.drawable.carrot,R.drawable.cauliflower,R.drawable.mango,R.drawable.onion,R.drawable.orange,R.drawable.potato,R.drawable.pumpkin,R.drawable.tomato};

    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.customlistview);

        CustomAdapter customAdapter = new CustomAdapter(fruitList,imageList,getApplicationContext());
//        CustomAdapter customAdapter = new CustomAdapter(fruitList,imageList, );
        listView.setAdapter(customAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                TextView temp =view.findViewById(R.id.textView);

                String str ="You Selected "+temp.getText().toString();
                Toast.makeText(getApplicationContext(), str, Toast.LENGTH_SHORT).show();
            }
        });
    }
}