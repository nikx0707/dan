import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EmployeeDetailsGUI extends JFrame implements ActionListener {
    private Choice empNoChoice;
    private JTable empDetailsTable;

    public EmployeeDetailsGUI() {
        super("Employee Details");

        // create and configure the choice component
        empNoChoice = new Choice();
        empNoChoice.add("1001");
        empNoChoice.add("1002");
        empNoChoice.add("1003");
        empNoChoice.add("1004");
        empNoChoice.add("1005");
        empNoChoice.addActionListener(this);

        // create the table model
        String[] columns = {"Emp No", "Emp Name", "Salary", "Designation"};
        String[][] data = {{"1001", "John Doe", "50000", "Manager"},
                           {"1002", "Jane Smith", "45000", "Programmer"},
                           {"1003", "Bob Johnson", "55000", "Analyst"},
                           {"1004", "Sarah Lee", "60000", "Architect"},
                           {"1005", "Tom Green", "40000", "Developer"}};
        DefaultTableModel model = new DefaultTableModel(data, columns);

        // create and configure the table
        empDetailsTable = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(empDetailsTable);

        // add components to the GUI
        JPanel panel = new JPanel(new GridLayout(2, 1));
        panel.add(empNoChoice);
        panel.add(scrollPane);
        add(panel);

        // configure the frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // get the selected employee number from the choice component
        String empNo = empNoChoice.getSelectedItem();

        // find the row in the table that matches the selected employee number
        DefaultTableModel model = (DefaultTableModel) empDetailsTable.getModel();
        for (int row = 0; row < model.getRowCount(); row++) {
            String tableEmpNo = (String) model.getValueAt(row, 0);
            if (tableEmpNo.equals(empNo)) {
                // select the row in the table
                empDetailsTable.setRowSelectionInterval(row, row);
                break;
            }
        }
    }

    public static void main(String[] args) {
        new EmployeeDetailsGUI();
    }
}
