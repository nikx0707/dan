package com.example.toggleswitching;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    ToggleButton bt;
    Switch wifi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bt=(ToggleButton) findViewById(R.id.bt);
        wifi=(Switch) findViewById(R.id.wifi);

        bt.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b)
            {
                if (b){
                    Toast.makeText(getApplicationContext(), "Your Bluetooth is on", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(getApplicationContext(), "Your Bluetooth is off", Toast.LENGTH_SHORT).show();
                }

            }
        });
        wifi.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b)
            {
             if (b)
             {
                 Toast.makeText(getApplicationContext(), "your wifi is on", Toast.LENGTH_SHORT).show();
             }
             else {
                 Toast.makeText(getApplicationContext(), "your wifi is off", Toast.LENGTH_SHORT).show();
             }
            }
        });
    }
}