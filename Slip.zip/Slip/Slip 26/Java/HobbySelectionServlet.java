import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class HobbySelectionServlet extends HttpServlet {
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType("text/html");

    // Check if cookie already exists
    String hobby = null;
    Cookie[] cookies = request.getCookies();
    if (cookies != null) {
      for (Cookie cookie : cookies) {
        if (cookie.getName().equals("hobby")) {
          hobby = cookie.getValue();
          break;
        }
      }
    }

    // Write HTML response
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<head><title>Hobby Selection</title></head>");
    out.println("<body>");
    out.println("<h1>Select Your Hobby</h1>");
    out.println("<form method='post'>");
    out.println("<input type='radio' name='hobby' value='painting' " + (hobby != null && hobby.equals("painting") ? "checked" : "") + "> Painting<br>");
    out.println("<input type='radio' name='hobby' value='drawing' " + (hobby != null && hobby.equals("drawing") ? "checked" : "") + "> Drawing<br>");
    out.println("<input type='radio' name='hobby' value='singing' " + (hobby != null && hobby.equals("singing") ? "checked" : "") + "> Singing<br>");
    out.println("<input type='radio' name='hobby' value='swimming' " + (hobby != null && hobby.equals("swimming") ? "checked" : "") + "> Swimming<br>");
    out.println("<input type='reset' value='Reset'>");
    out.println("<input type='submit' value='Submit'>");
    out.println("</form>");
    out.println("</body>");
    out.println("</html>");
  }

  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    // Read hobby selection
    String hobby = request.getParameter("hobby");

    // Create cookie
    Cookie cookie = new Cookie("hobby", hobby);

    // Set cookie expiration to 1 day
    cookie.setMaxAge(24 * 60 * 60);

    // Add cookie to response
    response.addCookie(cookie);

    // Redirect back to same page
    response.sendRedirect(request.getRequestURI());
  }
}
