import java.sql.*;

public class CollegeListExample {
    public static void main(String[] args) {
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to the database
            String url = "jdbc:mysql://localhost:3306/mydatabase";
            String username = "myuser";
            String password = "mypassword";
            Connection connection = DriverManager.getConnection(url, username, password);

            // Query the database for college names
            String query = "SELECT CName FROM College";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            // Print the college names
            while (resultSet.next()) {
                String collegeName = resultSet.getString("CName");
                System.out.println(collegeName);
            }

            // Close the resources
            resultSet.close();
            statement.close();
            connection.close();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
