import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class TempleApp extends Application {
    private final int WIDTH = 600;
    private final int HEIGHT = 400;

    @Override
    public void start(Stage stage) {
        Canvas canvas = new Canvas(WIDTH, HEIGHT);
        GraphicsContext gc = canvas.getGraphicsContext2D();

        Group root = new Group();
        root.getChildren().add(canvas);

        Scene scene = new Scene(root, WIDTH, HEIGHT);
        stage.setScene(scene);
        stage.show();

        Thread roofThread = new Thread(() -> {
            drawRoof(gc);
        });
        roofThread.start();

        Thread pillarsThread = new Thread(() -> {
            drawPillars(gc);
        });
        pillarsThread.start();

        Thread wallsThread = new Thread(() -> {
            drawWalls(gc);
        });
        wallsThread.start();
    }

    private void drawRoof(GraphicsContext gc) {
        gc.setFill(Color.RED);
        gc.fillPolygon(new double[] { 0, WIDTH / 2, WIDTH }, new double[] { HEIGHT / 4, 0, HEIGHT / 4 }, 3);
    }

    private void drawPillars(GraphicsContext gc) {
        gc.setFill(Color.WHITE);
        gc.fillRect(50, HEIGHT / 4, 30, HEIGHT / 2);
        gc.fillRect(WIDTH - 80, HEIGHT / 4, 30, HEIGHT / 2);
    }

    private void drawWalls(GraphicsContext gc) {
        gc.setFill(Color.YELLOW);
        gc.fillRect(80, HEIGHT / 2, WIDTH - 160, HEIGHT / 2 - 20);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
