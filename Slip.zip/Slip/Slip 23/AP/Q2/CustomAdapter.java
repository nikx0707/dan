package com.example.bookauthor;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class CustomAdapter extends BaseAdapter {

    String book[];
    String author[];
    Context context;
    LayoutInflater layoutInflater;

    public CustomAdapter(String[] book, String[] author, Context context) {
        this.book = book;
        this.author = author;
        this.context = context;

        layoutInflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return book.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        view = layoutInflater.inflate(R.layout.activity_custom_list_view,null);

        TextView txt1 = view.findViewById(R.id.bookName);
        TextView txt2 = view.findViewById(R.id.authorName);

        txt1.setText(book[i]);
        txt2.setText(author[i]);


        return view;

    }
}
