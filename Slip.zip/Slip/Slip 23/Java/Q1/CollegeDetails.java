import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class CollegeDetails extends JFrame {

    private JPanel panel;
    private JTable table;
    private DefaultTableModel model;

    public CollegeDetails() {
        setTitle("College Details");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 400);

        // create the panel and table
        panel = new JPanel();
        model = new DefaultTableModel();
        table = new JTable(model);

        // add columns to the model
        model.addColumn("CID");
        model.addColumn("CName");
        model.addColumn("Address");
        model.addColumn("Year");

        // add rows to the model
        model.addRow(new Object[]{"001", "ABC College", "123 Main St.", "2022"});
        model.addRow(new Object[]{"002", "XYZ College", "456 Oak St.", "2023"});

        // add the table to the panel
        panel.add(new JScrollPane(table));

        // add the panel to the frame
        add(panel);

        setVisible(true);
    }

    public static void main(String[] args) {
        new CollegeDetails();
    }
}
