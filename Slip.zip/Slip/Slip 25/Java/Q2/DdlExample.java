import java.sql.*;

public class DdlExample {
    public static void main(String[] args) {
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to the database
            String url = "jdbc:mysql://localhost:3306/mydatabase";
            String username = "myuser";
            String password = "mypassword";
            Connection connection = DriverManager.getConnection(url, username, password);

            // Create a table
            String createTableQuery = "CREATE TABLE employees (id INT PRIMARY KEY, name VARCHAR(50), salary DOUBLE)";
            Statement statement = connection.createStatement();
            statement.executeUpdate(createTableQuery);

            // Alter the table
            String alterTableQuery = "ALTER TABLE employees ADD COLUMN age INT";
            statement.executeUpdate(alterTableQuery);

            // Drop the table
            String dropTableQuery = "DROP TABLE employees";
            statement.executeUpdate(dropTableQuery);

            // Close the resources
            statement.close();
            connection.close();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
