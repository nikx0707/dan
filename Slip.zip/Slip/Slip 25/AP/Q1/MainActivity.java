package com.example.ratingbar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button submit;
    RatingBar ratingbar;
    TextView ans;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        submit = findViewById(R.id.submit);
        ratingbar = findViewById(R.id.ratingbar);
        ans = findViewById(R.id.ans);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str =String.valueOf(ratingbar.getRating());
                ans.setText("Your Product Rating is "+str+" Stars");

//                Toast.makeText(MainActivity.this, "Your Product Rating is "+str+" Stars", Toast.LENGTH_SHORT).show();
            }
        });
    }
}