import java.sql.*;

public class ScrollableResultSetExample {

    public static void main(String[] args) {
        try {
            // Load the JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Connect to the database
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "");

            // Create a statement with a scrollable ResultSet
            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);

            // Execute the query
            ResultSet rs = stmt.executeQuery("SELECT * FROM Teacher");

            // Move the cursor to the last row
            rs.last();

            // Get the total number of rows in the ResultSet
            int rowCount = rs.getRow();

            // Move the cursor back to the first row
            rs.beforeFirst();

            // Print the ResultSet
            while (rs.next()) {
                System.out.println("TID: " + rs.getInt("TID") +
                        ", TName: " + rs.getString("TName") +
                        ", Salary: " + rs.getInt("Salary") +
                        ", Subject: " + rs.getString("Subject"));
            }

            // Close the ResultSet, statement, and connection
            rs.close();
            stmt.close();
            conn.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
}
