import java.awt.*;
import java.applet.*;

public class CarApplet extends Applet implements Runnable {

    int x, y; // coordinates of the car
    int speed; // speed of the car
    Thread animator; // thread for animation

    public void init() {
        x = 0; // initial x-coordinate of the car
        y = 50; // initial y-coordinate of the car
        speed = 5; // speed of the car
    }

    public void start() {
        animator = new Thread(this); // create a new thread for animation
        animator.start(); // start the thread
    }

    public void stop() {
        animator = null; // stop the animation thread
    }

    public void run() {
        while (true) {
            x += speed; // move the car horizontally
            if (x > getWidth()) {
                x = 0; // reset the x-coordinate if the car goes off the screen
            }
            repaint(); // redraw the applet
            try {
                Thread.sleep(100); // pause the animation for a short time
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void paint(Graphics g) {
        // draw the car
        g.setColor(Color.red);
        g.fillRect(x, y, 50, 30);
        g.setColor(Color.black);
        g.drawRect(x, y, 50, 30);
        g.drawRect(x + 10, y - 10, 30, 10);
        g.drawOval(x + 10, y + 20, 10, 10);
        g.drawOval(x + 30, y + 20, 10, 10);
    }
}
