
import java.io.File;

public class FileExtensionDemo {
    public static void main(String[] args) {
        String directoryPath = "/path/to/directory";
        String fileExtension = ".txt";

        File directory = new File(directoryPath);
        File[] fileList = directory.listFiles((dir, name) -> name.endsWith(fileExtension));

        for (File file : fileList) {
            System.out.println(file.getName());
        }
    }
}


//Note that you need to replace /path/to/directory with the actual path to the directory you want to search,