public class OddPrimeNumbers implements Runnable {
    
    private int n;
    private boolean isOdd;
    
    public OddPrimeNumbers(int n, boolean isOdd) {
        this.n = n;
        this.isOdd = isOdd;
    }
    
    public void run() {
        if (isOdd) {
            displayOddNumbers();
        } else {
            displayPrimeNumbers();
        }
    }
    
    private void displayOddNumbers() {
        for (int i = 1; i <= n; i += 2) {
            System.out.println(i);
        }
    }
    
    private void displayPrimeNumbers() {
        for (int i = 2; i <= n; i++) {
            boolean isPrime = true;
            for (int j = 2; j <= Math.sqrt(i); j++) {
                if (i % j == 0) {
                    isPrime = false;
                    break;
                }
            }
            if (isPrime) {
                System.out.println(i);
            }
        }
    }
    
    public static void main(String[] args) {
        int n = 50;
        Thread oddThread = new Thread(new OddPrimeNumbers(n, true));
        Thread primeThread = new Thread(new OddPrimeNumbers(n, false));
        oddThread.start();
        primeThread.start();
    }
}
