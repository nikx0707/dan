import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class SessionTimeoutServlet extends HttpServlet {
    
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        
        // Set the maximum inactive time interval to 60 seconds
        session.setMaxInactiveInterval(60);
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><head><title>Session Timeout</title></head><body>");
        out.println("<h3>Session Timeout has been changed to 60 seconds.</h3>");
        out.println("</body></html>");
        out.close();
    }
}
